this.TWIST = this.TWIST || {};

(function () {
    "use strict";

    TWIST.Observer = new EventEmitter();
    TWIST.Observer._canvasList = [];
    TWIST.imagePath = '../src/themes/jarvanIV/images/';
    
})();